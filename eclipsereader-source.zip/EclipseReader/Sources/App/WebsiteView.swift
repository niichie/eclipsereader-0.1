import SwiftUI
import WebKit

/// Unmodified site viewing. No page extraction, cookie export, script injection or challenge solving.
struct WebsiteView: View {
    let url: URL
    /// When set, shows a button that hands the current page to the native reader.
    var onRead: ((URL) -> Void)? = nil
    @Environment(\.dismiss) private var dismiss
    @StateObject private var browser = WebsiteBrowser()
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Text("Website Mode · Native page turns and exact page progress are unavailable here.")
                    .font(.footnote).foregroundStyle(.secondary).padding(12)
                WebsiteSurface(browser: browser, url: url)
                if let error = browser.error {
                    Text(error).font(.subheadline).foregroundStyle(.orange).padding(12)
                }
                HStack {
                    Button { browser.webView.goBack() } label: { Label("Back", systemImage: "chevron.left") }
                        .disabled(!browser.canGoBack)
                    Spacer()
                    if browser.loading { ProgressView() }
                    Button { browser.reload() } label: { Label("Reload", systemImage: "arrow.clockwise") }
                    Spacer()
                    if let onRead {
                        Spacer()
                        Button { onRead(browser.webView.url ?? url) } label: { Label("Read here", systemImage: "book") }
                            .accessibilityHint("Opens this page in the eclipsereader page reader")
                    }
                    Spacer()
                    Link("Safari", destination: browser.webView.url ?? url)
                }.padding(16).background(.bar)
            }.navigationTitle(url.host ?? "Website").navigationBarTitleDisplayMode(.inline)
                .toolbar { Button("Done") { dismiss() } }
        }.preferredColorScheme(.dark)
    }
}

@MainActor
final class WebsiteBrowser: NSObject, ObservableObject, WKNavigationDelegate {
    let webView: WKWebView
    @Published var error: String?
    @Published var loading = true
    @Published var canGoBack = false
    var homeHost: String?
    override init() {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self; webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false; webView.backgroundColor = .black
    }
    func reload() { error = nil; webView.reload() }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { loading = true; error = nil }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loading = false; canGoBack = webView.canGoBack }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { fail(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { fail(error) }
    private func fail(_ error: Error) {
        loading = false; canGoBack = webView.canGoBack
        if (error as NSError).code != NSURLErrorCancelled { self.error = error.localizedDescription }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping @MainActor @Sendable (WKNavigationActionPolicy) -> Void) {
        // Subresources remain under WebKit control. Unexpected top-level links stay in Safari.
        if navigationAction.targetFrame?.isMainFrame != false,
           let url = navigationAction.request.url,
           ReadBerserkParser.normalize(url.absoluteString, relativeTo: ReadBerserkParser.home) == nil,
           !sameSite(url) {
            decisionHandler(.cancel)
            if navigationAction.navigationType == .linkActivated && ["https", "http"].contains(url.scheme ?? "") {
                UIApplication.shared.open(url)
            }
            return
        }
        decisionHandler(.allow)
    }
    /// Top-level navigation may stay on the site the user opened (including subdomains).
    private func sameSite(_ url: URL) -> Bool {
        guard WebLink.publicHTTPS(url), let host = url.host?.lowercased(), let home = homeHost else { return false }
        func root(_ h: String) -> String { h.split(separator: ".").suffix(2).joined(separator: ".") }
        return root(host) == root(home)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        loading = false; error = "The website process stopped. Tap Reload to reopen it."
    }
}

struct WebsiteSurface: UIViewRepresentable {
    @ObservedObject var browser: WebsiteBrowser
    let url: URL
    func makeUIView(context: Context) -> WKWebView { browser.homeHost = url.host?.lowercased(); browser.webView.load(URLRequest(url: url)); return browser.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    static func dismantleUIView(_ uiView: WKWebView, coordinator: ()) { uiView.stopLoading() }
}
