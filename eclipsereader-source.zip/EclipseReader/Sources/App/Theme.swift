import SwiftUI

/// eclipsereader's look: near-black surfaces, a violet-and-amber corona accent, serif wordmark.
enum Eclipse {
    /// Deep violet accent with a warm yellow highlight, kept subtle so artwork stays the focus.
    static let accent = Color(red: 0.54, green: 0.30, blue: 0.93)
    static let highlight = Color(red: 1.0, green: 0.80, blue: 0.20)
    static let surface = Color(white: 0.075)
    static let surfaceHigh = Color(white: 0.12)
    static let hairline = Color.white.opacity(0.08)
    static let corona = AngularGradient(colors: [accent, highlight, accent.opacity(0.5), accent], center: .center)
}

/// Black backdrop with a faint corona glow at the top; the artwork stays the brightest thing on screen.
struct EclipseBackground: View {
    var body: some View {
        ZStack(alignment: .top) {
            Color.black
            RadialGradient(colors: [Eclipse.accent.opacity(0.28), Eclipse.accent.opacity(0.06), .clear],
                           center: .top, startRadius: 0, endRadius: 520)
                .frame(height: 560)
                .offset(y: -120)
        }
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }
}

/// The eclipse logo: a black disc with a violet-and-amber corona.
struct EclipseMark: View {
    var size: CGFloat = 26
    var body: some View {
        ZStack {
            Circle().fill(Eclipse.corona).blur(radius: size * 0.18).opacity(0.9)
            Circle().strokeBorder(Eclipse.corona, lineWidth: max(1.5, size * 0.07))
            Circle().fill(Color.black).padding(size * 0.11)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

struct EclipseWordmark: View {
    var body: some View {
        HStack(spacing: 8) {
            EclipseMark(size: 22)
            HStack(spacing: 0) {
                Text("eclipse").font(.system(.title3, design: .serif).weight(.black))
                Text("reader").font(.system(.title3, design: .serif).weight(.regular)).foregroundStyle(.secondary)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("eclipsereader")
    }
}

extension View {
    /// Raised surface used for cards and panels.
    func eclipseCard(cornerRadius: CGFloat = 18) -> some View {
        background(Eclipse.surface, in: RoundedRectangle(cornerRadius: cornerRadius))
            .overlay(RoundedRectangle(cornerRadius: cornerRadius).strokeBorder(Eclipse.hairline))
    }
}
